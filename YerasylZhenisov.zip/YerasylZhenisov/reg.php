<?php 
	$connect=mysql_connect('localhost','root','') or die(mysql_error());
	mysql_select_db('yerasyl');

	if(isset($_POST['submit'])){
		$login=$_POST['login'];
		$password=$_POST['password'];
		$r_password=$_POST['r_password'];
		if($password==$r_password){
			$password = md5($password);
			$query=mysql_query("INSERT INTO users VALUES('','$login','$password')") or die(mysql_error());
		}
		else{
			die('invalid password');
		}
		header('location:address.php');
	}
 ?>

<form method="post" action="reg.php">
	<input type="text" name="login" placeholder="login.." required>
	<input type="password" name="password" placeholder="password.." required>
	<input type="password" name="r_password" placeholder="confirm password.." required>
	<input type="submit" name="submit" value="registr">
</form>