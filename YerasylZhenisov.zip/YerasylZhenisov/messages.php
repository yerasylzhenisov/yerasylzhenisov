<?php  session_start(); ?>
<?php
$db= mysqli_connect("localhost","root","");
mysqli_select_db($db,"yerasyl");   

$forum= "";
$forum_email = $_POST['forum_email'];

$forum_number = $_POST['forum_number'];

$forum_message = $_POST['forum_message'];

	
	
	if((!$forum_email) || (!$forum_number) || (!$forum_message)){
		$forum = "<p style='color: blue; font-weight: bold; font-size: 30px; font-family: arial;'>Хорошая работа</p>";
	}
	else{
		include_once("db.php");
			$sql = mysqli_query($db,"INSERT INTO forum VALUES(null,'$forum_email','$forum_number','$forum_message'");
			$forum = "<p style='color: red; font-weight: bold;'>Ваша заявка успешно отправлена</p>";
			
			
	
}

?>
<html lang="en">
<head>
    <style type="text/css">
    .class{
  background-color: white;
  width: 50px;
    }
    </style>
    <meta charset="utf-8">
    <title>Юридические услуги в Алматы РК, Бухгалтерские услуги и государственные </title>
    <link rel="stylesheet" href="css/style.css" media="screen" title="no title" charset="utf-8">
    <script src="js/jquery.js"></script>
    <script src="js/main.js" charset="utf-8"></script>
  </head>
  <body>
<div class="background">
  <img src="files/back.jpg" alt="" width="100%;" height="100%" style="position:fixed;z-index:-1"/>	
<title>Онлайн форум</title>
<meta charset="utf-8">
<meta name="keywords" content="">
<meta name="description" content="">

	
</head>
<body>
   <div class="main">
 <table border="0" style="width: 100%; margin: 0 auto;">
  <tr>
<td style="width: 150% ; ">
 <h2 class="title" style="float:left; padding-left:100px;"> Oнлайн форум</h2>
 <br/>
  <form action="messages.php" method="post" enctype="multipart/form-data">
   <table width="100%" cellpadding="4" cellspacing="4" border="0" >
    <tr>
     <td align="center"><label>Email адрес:</label></td>
     <td align="center"><input type="email" name="forum_email" class="text" maxlength="100" style="width:500px;height:100px;padding:5px;resize:none" placeholder="input@gmail.com" value="<?php
	 if(isset($_SESSION['email'])){ 
	 echo $_SESSION['email'];} ?>"/></td>
    </tr>
    <tr>          
     <td align="left"><label>Телефон:</label></td>
     <td align="left"><input type="phone" name="forum_number" class="t" maxlength="50" style="width:600px;height:100px;padding:5px;resize:none" placeholder="Ваш номер телефона"/></td>
	  
    </tr>
    <tr>
     <td align="right"><label>Сообщение:</label></td>
     <td align="right">
      <textarea name="forum_message" style="width:1000px;height:300px;resize:none;"  placeholder="Онлайн форум">
      </textarea>  
     </td>
    </tr>
    <tr>
     <td align="center" colspan="3"><input type="submit" name="submit" id="button" value="Отправить"/></td>
	 
    </tr>
    <tr>
    <td align="left" colspan="2"><?php echo $forum; ?></td>
	
    </tr>
   </table>
  </form>
 </td>
</tr>
	</table>
	</div>
</body>
</html>