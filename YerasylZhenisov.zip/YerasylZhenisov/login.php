<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Юридические услуги в Алматы РК, Бухгалтерские услуги и государственн</title>
    <link rel="stylesheet" href="css/style.css" media="screen" title="no title" charset="utf-8">
    <script src="js/jquery.js"></script>
    <script src="js/main.js" charset="utf-8"></script>
  </head>
  <body>

<div class="background">
  <img src="files/back.jpg" alt="" width="100%;" height="100%" style="position:fixed;z-index:-1"/>
          <div><form method="post" action="login_check.php">
  <input type="text" name="login" placeholder="login..">
  <input type="password" name="password" placeholder="password..">
  <input type="submit" name="submit" value="enter"> 
</form><a href="reg.php"><button class='btn'>Регистрация</button></a></div>
        



</body>
</html>
