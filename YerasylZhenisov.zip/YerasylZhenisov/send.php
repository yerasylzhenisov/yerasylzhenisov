<?php
require_once('mail/PHPMailerAutoload.php');
//файлы
$host = $_SERVER["HTTP_HOST"];
$name = $_GET['name'];
$surname = $_GET['surname'];
$company = $_GET['company'];
$email = $_GET['email'];
$type = $_GET['selection'];
$text = $_GET['text'];

$mail = new PHPMailer();
$mail->IsSMTP(); 
$mail->SMTPDebug = 4; 
$mail->SMTPAuth = true; 
$mail->SMTPSecure = 'ssl'; 
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; 
$mail->IsHTML(true);

$mail->Username = "yatakoisam@gmail.com";
$mail->Password = "Admin123123";

$mail->SetFrom("yatakoisam@gmail.com");
$mail->Body = "
Компания                 : $company"."<br>\n"."
Контактное лицо          : $name $surname"."<br>\n"."
Тип услуги               : $type"."<br>\n"."
E-mail заказчика         : $email"."<br>\n"."
Информация               : $text"."<br>\n";

$mail->AddAddress("zhenisyerasyl.@gmail.com");

if(!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    header('Location: http://'.$host.'/uncleSite/index.php');
}
?>
