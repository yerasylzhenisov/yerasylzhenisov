<html>
<head>
	<title>dsadsadsa</title>
	<meta charset="utf-8">
</head>
<body>
	<a href="login.php">
		Спасибо, за рег.ывлдоавдлыодвыл! Можете авторавыальывдаоываоыв.
	</a>
</body>
</html>