<!DOCTYPE html>
<html lang="ru">
<head>
	    <style>
    .class{
  background-color: white;
  width: 50px;
    }
    </style>
    <meta charset="utf-8">
    <title>онлайн форум</title>
    <link rel="stylesheet" href="css/style.css" media="screen" title="no title" charset="utf-8">
    <script src="js/jquery.js"></script>
    <script src="js/main.js" charset="utf-8"></script>
  </head>
  <body>
<div class="background">
  <img src="files/back.jpg" alt="" width="100%;" height="100%" style="position:fixed;z-index:-1"/>
<title>онлайн форум</title>
<meta charset="utf-8" />
</head>
<body>
 <div class="base">
  <table border="1" style="width: 50%; margin: 0 auto;"> 


          <td style="width: 100%;">
            <h2 class="page_title">Проверка отзывов</h2>
            <br/>
<?php
include_once("db.php");
if(isset($_POST['delete'])){
$DeleteQuery = "DELETE FROM forum WHERE id='$_POST[hidden]'"; 
mysql_query($DeleteQuery);
};

$sql = "SELECT * FROM forum ORDER BY forum_name DESC";
$myData = mysql_query($sql);
echo "<table width=1000 cellspacing=0 cellpadding=20 border=15 color:'red'>
<tr>

<td align=center width=600><b>Email</b></td>
<td align=center width=600><b>Телефон</b></td>
<td align=center width=600><b>Сообшение</b></td>
</tr>";
while($record = mysql_fetch_array($myData)){
echo "<form action=forum.php method=post>";
echo "<tr>";
echo "<td align=left>"  . $record['forum_email'] . " </td>";
echo "<td align=left>"  . $record['forum_number'] . " </td>";
echo "<td align=left>"  . $record['forum_message'] . " </td>";
echo "<td align=left>"  . $record['forum_date'] . " </td>";
echo "<td align=left>"  . "<input type=hidden name=hidden value=" . $record['id'] . " </td>";
echo "<td align=left>"  . "<input type=submit name=Удалить	 value=Delete" . " </td>"; // тут можно удалять все
echo "</tr>";
echo "</form>";
}
echo "</table>";
mysql_close();
?>
</td>

</table>
</div>
</body>
</html>
