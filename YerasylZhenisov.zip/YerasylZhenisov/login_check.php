 <?php 
    include ("db.php");

  
    $login=$_POST['login'];
    $password=md5($_POST['password']);
      $connect=mysql_connect('localhost','root','') or die(mysql_error());
  mysql_select_db('yerasyl');
    
    $query=mysql_query("SELECT * FROM users WHERE login='$login' AND password = '$password'",$connect);
    $user_data = mysql_fetch_array($query);
    if($user_data['status']==1){
          header ("Location:application.php");
        }
    
    else if($user_data['status']==0){
               
      if($user_data['password']==$password){
        session_start();
        $_SESSION['login']=$user_data['login'];
        $_SESSION['password']=$user_data['password'];
        $_SESSION['id']=$user_data['id'];
        header('location:index.php');}
      }
       else{
      echo "Wrong password or login";
    }

   
   
 ?>